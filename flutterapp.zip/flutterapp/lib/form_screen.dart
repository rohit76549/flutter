import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rounded_date_picker/flutter_rounded_date_picker.dart';


class FormScreen extends StatefulWidget {
  @override
  _FormScreenState createState() => _FormScreenState();
}
class MultiSelectDialogItem<V> {
  const MultiSelectDialogItem(this.value, this.label);

  final V value;
  final String label;
}

class MultiSelectDialog<V> extends StatefulWidget {
  MultiSelectDialog({ Key? key,  required this.items,required this.initialSelectedValues}) : super(key: key);

  final List<MultiSelectDialogItem<V>> items;
  final Set<V> initialSelectedValues;

  @override
  State<StatefulWidget> createState() => _MultiSelectDialogState<V>();
}

class _MultiSelectDialogState<V> extends State<MultiSelectDialog<V>> {
  final _selectedValues = Set<V>();

  void initState() {
    super.initState();
    if (widget.initialSelectedValues != null) {
      _selectedValues.addAll(widget.initialSelectedValues);
    }
  }

  void _onItemCheckedChange(V itemValue, bool checked) {
    setState(() {
      if (checked) {
        _selectedValues.add(itemValue);
      } else {
        _selectedValues.remove(itemValue);
      }
    });
  }

  void _onCancelTap() {
    Navigator.pop(context);
  }

  void _onSubmitTap() {
    Navigator.pop(context, _selectedValues);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Select Country'),
      contentPadding: EdgeInsets.only(top: 12.0),
      content: SingleChildScrollView(
        child: ListTileTheme(
          contentPadding: EdgeInsets.fromLTRB(14.0, 0.0, 24.0, 0.0),
          child: ListBody(
            children: widget.items.map(_buildItem).toList(),
          ),
        ),
      ),
      actions: <Widget>[
        FlatButton(
          child: Text('CANCEL'),
          onPressed: _onCancelTap,
        ),
        FlatButton(
          child: Text('OK'),
          onPressed: _onSubmitTap,
        )
      ],
    );
  }

  Widget _buildItem(MultiSelectDialogItem<V> item) {
    final checked = _selectedValues.contains(item.value);
    return CheckboxListTile(
      value: checked,
      title: Text(item.label),
      controlAffinity: ListTileControlAffinity.leading,
      onChanged: (checked) => _onItemCheckedChange(item.value, checked!),
    );
  }
}

class _FormScreenState extends State<FormScreen> {
  String _firstname='';

  late DateTime _date;
  final GlobalKey<FormState>_formkey = GlobalKey<FormState>();
  final dateController = TextEditingController();
  final genderController = TextEditingController();
  final bloodgroupController=TextEditingController();
  final allergiesController=TextEditingController();


  @override
  void dispose() {
    // Clean up the controller when the widget is removed
    dateController.dispose();
    genderController.dispose();
    bloodgroupController.dispose();
    super.dispose();
  }
  /*@override
  void initState(){
    super.initState();
    _date=DateTime.now();
  }*/



  void _showMultiSelect(BuildContext context) async {
   // multiItem = [];
   // populateMultiselect();
    //final items = multiItem;
    final items = <MultiSelectDialogItem<int>>[
      MultiSelectDialogItem(1, 'Nausea'),
      MultiSelectDialogItem(2, 'Headache'),
      MultiSelectDialogItem(3, 'Chest Pain'),
      MultiSelectDialogItem(4, 'Fever'),
    ];

    final selectedValues = await showDialog<Set<int>>(
      context: context,
      builder: (BuildContext context) {
        return MultiSelectDialog(
          items: items,
          initialSelectedValues: [1,2].toSet(),
        );
      },
    );
    print(selectedValues);
  }



  Widget _buildFirstName(){
    return Container(
      width:50.0,
      child: TextFormField(

        decoration: InputDecoration(hintText: 'First Name',),
        validator:(String? value){
          if(value == null || value.isEmpty){
            return 'Name is Required';
          }
        },
        onSaved: (String? value){
          _firstname= value.toString();
        },
      ),
    );
  }
  Widget _buildLastName(){
    return Container(
      width: 20.0,
      child: TextFormField(

        decoration: InputDecoration(hintText: 'Last Name',),
        validator:(value){
          if(value == null || value.isEmpty){
            return 'Name is Required';
          }
        },
        onSaved: (value){
          // _firstname= value;
        },
      ),
    );
  }
  Widget _buildDOB(){
    return Container(
      width: 50.0,
        child: TextField(
        readOnly: true,
        controller: dateController,
        decoration: InputDecoration(
        hintText: 'Date of Birth'
        ),
          onTap: () async {
            var date = await showRoundedDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime(1900),
                lastDate: DateTime(2100),
                borderRadius: 20,
              height: 300,
              background: Colors.white,
              theme: ThemeData(
              primaryColor: Colors.orange[400],
              accentColor: Colors.orange,
              dialogBackgroundColor: Colors.grey[50],
              textTheme: TextTheme(
                body1: TextStyle(color: Colors.black),
                caption: TextStyle(color: Colors.black),
              ),
              disabledColor: Colors.orange,
              accentTextTheme: TextTheme(
                body2 : TextStyle(color: Colors.black),
              ),
            ),

            );
                dateController.text = date.toString().substring(0, 10);

          }
          )
    );
  }
  Widget _buildGender(){
    return Container(
      width: 50.0,
      child: TextFormField(
        controller: genderController,
        decoration: InputDecoration(hintText: 'Gender',),
        validator:(value){
          if(value == null || value.isEmpty){
            return 'Must be filled';
          }
        },
          onTap: (){
            _showSimpleModalDialog(context);
          },
        onSaved: (value){
          // _firstname= value;
        },
      ),
    );
  }
  _showSimpleModalDialog(context){
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            backgroundColor: Colors.grey[50],
            shape: RoundedRectangleBorder(
                borderRadius:BorderRadius.circular(20.0)),
            child: Container(
              constraints: BoxConstraints(maxHeight:300.0),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20.0,10.0,20.0,10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Text('SELECT GENDER',
                        style: TextStyle(fontSize: 24,color: Colors.blue[800]),),
                    ),
                      SizedBox(height: 10,),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(40.0)),
                            primary: Colors.orange[600],
                            //padding: EdgeInsets.fromLTRB(100.0, 20.0, 100.0, 20.0),
                            textStyle: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.normal,
                            )),
                        onPressed: (){
                          genderController.text='Male';
                          Navigator.pop(context);
                        },
                        child: Text('Male',
                          style: TextStyle(fontSize: 24,color: Colors.white),),

                      ),

                    SizedBox(height: 20,),


                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(40.0)),
                            primary: Colors.orange[600],
                            //padding: EdgeInsets.fromLTRB(100.0, 20.0, 100.0, 20.0),
                            textStyle: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.normal,
                            color: Colors.white),),
                        onPressed: (){
                          genderController.text='Female';
                          Navigator.pop(context);
                        },
                        child: Text('Female',
                          style: TextStyle(fontSize: 24,color: Colors.white),),


                    ),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                      //TextButton(
                          //onPressed:(){},
                          //child:
                          //Text('SELECT',
                           // style: TextStyle(fontSize: 20)),

                     // ),
                         // SizedBox(width: 10,),
                          TextButton(
                            onPressed:(){
                              Navigator.pop(context);
                            },
                            child:
                            Text('CANCEL',
                                style: TextStyle(fontSize: 20)),

                          ),

                        ]),
                  ],
                ),
              ),
            ),
          );
        });
  }
  Widget _buildPincode(){
    return Container(
      width: 143.0,
      child: TextFormField(
        decoration: InputDecoration(hintText: 'Pincode'),
        validator:(String? value){
          if(value == null || value.isEmpty){
            return 'Must be filled';
            };
          if (value.length != 6)
            return 'Pincode must be of 6 digit';
        },
        onSaved: (String? value){
          // _firstname= value.toString();
        },
      ),
    );
  }
  Widget _buildPhoneNumber(){
    return Container(
      child: TextFormField(
        decoration: InputDecoration(hintText: 'Emergency Phone Number'),
        validator:(value){
          if(value == null || value.isEmpty){
            return 'Must be filled';
          }
          if (value.length != 10)
            return 'Mobile Number must be of 10 digit';
        },
        onSaved: (value){
          // _firstname= value;
        },
      ),
    );
  }
  Widget _buildBloodGroup(){
    return Container(
      width: 143.0,

      child: TextFormField(
        controller: bloodgroupController,
        decoration: InputDecoration(hintText: 'Blood Group'),
        validator:(value){
          if(value == null || value.isEmpty){
            return 'Must be filled';
          }
        },onTap: (){
        _bloodgroupModalDialog(context);
      },
        onSaved: (value){
          // _firstname= value;
        },
      ),
    );
  }
  _bloodgroupModalDialog(context){

    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            backgroundColor: Colors.grey[50],
            shape: RoundedRectangleBorder(
                borderRadius:BorderRadius.circular(20.0)),
            child: Container(
              constraints: BoxConstraints(maxHeight:300.0),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20.0,10.0,20.0,10.0),

                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Text('Blood Group',
                        style: TextStyle(fontSize: 24,color: Colors.blue[800]),),
                    ),
                    SizedBox(height: 10,),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40.0)),
                          primary: Colors.orange[600],
                          //padding: EdgeInsets.fromLTRB(100.0, 20.0, 100.0, 20.0),
                          textStyle: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.normal,
                          )),
                      onPressed: (){
                        bloodgroupController.text='A+';
                        Navigator.pop(context);
                      },
                      child: Text('A+',
                        style: TextStyle(fontSize: 17,color: Colors.white),),

                    ),

                    SizedBox(height: 20,),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40.0)),
                          primary: Colors.orange[600],
                          //padding: EdgeInsets.fromLTRB(100.0, 20.0, 100.0, 20.0),
                          textStyle: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.normal,
                          )),
                      onPressed: (){
                        bloodgroupController.text='A-';
                        Navigator.pop(context);
                      },
                      child: Text('A-',
                        style: TextStyle(fontSize: 17,color: Colors.white),),

                    ),

                    SizedBox(height: 10,),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(40.0)),
                          primary: Colors.orange[600],
                          //padding: EdgeInsets.fromLTRB(100.0, 20.0, 100.0, 20.0),
                          textStyle: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.normal,
                          )),
                      onPressed: (){
                        bloodgroupController.text='B+';
                        Navigator.pop(context);
                      },
                      child: Text('B+',
                        style: TextStyle(fontSize: 17,color: Colors.white),),

                    ),

                    SizedBox(height: 8,),
                    Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          //TextButton(
                          //onPressed:(){},
                          //child:
                          //Text('SELECT',
                          // style: TextStyle(fontSize: 20)),

                          // ),
                          // SizedBox(width: 10,),
                          TextButton(
                            onPressed:(){
                              Navigator.pop(context);
                            },
                            child:
                            Text('CANCEL',
                                style: TextStyle(fontSize: 20)),

                          ),

                        ]),
                  ],
                ),
              ),
            ),
          );
        });

  }
  Widget _buildAllergies(){
    return Container(
      width: 50.0,
      child: TextFormField(
        controller: allergiesController,
        decoration: InputDecoration(hintText: 'Gender',),
        validator:(value){
          if(value == null || value.isEmpty){
            return 'Name is Required';
          }
        },
        onTap: (){

        },
        onSaved: (value){
          // _firstname= value;
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Tell us About Yourself")),
      body: Container(
        margin:EdgeInsets.all(10),
        child: Form(
          key: _formkey,
          child:Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children:<Widget> [
            Row(
                mainAxisAlignment: MainAxisAlignment.start,
              children:[
                Expanded(
                    flex:1,
                    child: _buildFirstName()),
                SizedBox(width: 60.0),
                Expanded(
                    flex:1,
                    child: _buildLastName()),

              ]
              ,
            ),
            SizedBox(height: 5.0),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children:[
                Expanded(
                    flex:1,
                    child: _buildDOB()),
                SizedBox(width: 60.0),
                Expanded(
                    flex:1,
                    child: _buildGender()),

              ]
              ,
            ),
            SizedBox(height: 5.0),
            _buildPincode(),
            SizedBox(height: 5.0),
            _buildPhoneNumber(),
            SizedBox(height: 5.0),
            _buildBloodGroup(),

            SizedBox(height: 0),
            RaisedButton(
              child: Text("Allergies"),
              onPressed: () => _showMultiSelect(context),
            ),

            FloatingActionButton(

              child:Text(
                'Create profile',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 10,


                ),
              ),
              onPressed: () async {
                if(!_formkey.currentState!.validate()){
                    return;
                  }
                await showDialog(
                    context: context,
                    builder: (context) => new AlertDialog(
                  title: new Text('Message'),
                  content: Text(
                      'Your file is saved.'),
                  actions: <Widget>[
                    new FlatButton(
                      onPressed: () {
                        Navigator.of(context, rootNavigator: true)
                            .pop(); // dismisses only the dialog and returns nothing
                      },
                      child: new Text('OK'),
                    ),
                  ],
                ),
                );
                //_formkey.currentState!.save(){
                  //print(_firstname);
                //};
              },

          )
          ],
        ),
        ),
      ),
    );
  }
}


